<?php get_header(); ?>

<div class="container-fluid">
  				<div class="row justify-content-center">
  					<h2>Гарячі Тури</h2>
  					<div class="w-100"></div>
  					<span>
  						Lorem Ipsum is simply dummy text of the printing and typesetting industry
  					</span>
  					<div class="w-100"></div>

  					<div class="card" style="width: 20rem;">
  						<div class="top col-12">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
  							78
  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
  							15
  						</div>
						<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-1.jpg" alt="Card image cap">
						<div class="card-body">
							<h5 class="card-title col-8">
								Hotel lampa&amp;PATAYA
								<div class="w-100"></div>
								<span>Іспанія</span>
							</h5>
							<div id="price">
								<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
								<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
								<div class="text">від 500 $</div>
							</div>
							<div class="card-text">
								Особи - двоє дорослих
								<div class="w-100"></div>
								від 15.03.2018  -  15.04.2018
							</div>
							<button type="button" class="btn btn-outline-secondary btn-sm">
								забронювати
							</button>
						</div>
					</div>

					<div class="card" style="width: 20rem;">
  						<div class="top col-12">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
  							78
  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
  							15
  						</div>
						<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-2.jpg" alt="Card image cap">
						<div class="card-body">
							<h5 class="card-title col-8">
								Hotel lampa&amp;PATAYA
								<div class="w-100"></div>
								<span>Іспанія</span>
							</h5>
							<div id="price">
								<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
								<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
								<div class="text">від 500 $</div>
							</div>
							<div class="card-text">
								Особи - двоє дорослих
								<div class="w-100"></div>
								від 15.03.2018  -  15.04.2018
							</div>
							<button type="button" class="btn btn-outline-secondary btn-sm">
								забронювати
							</button>
						</div>
					</div>


					<div class="card" style="width: 20rem;">
  						<div class="top col-12">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
  							78
  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
  							15
  						</div>
						<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-3.jpg" alt="Card image cap">
						<div class="card-body">
							<h5 class="card-title col-8">
								Hotel lampa&amp;PATAYA
								<div class="w-100"></div>
								<span>Іспанія</span>
							</h5>
							<div id="price">
								<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
								<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
								<div class="text">від 500 $</div>
							</div>
							<div class="card-text">
								Особи - двоє дорослих
								<div class="w-100"></div>
								від 15.03.2018  -  15.04.2018
							</div>
							<button type="button" class="btn btn-outline-secondary btn-sm">
								забронювати
							</button>
						</div>
					</div>


					<div class="card" style="width: 20rem;">
  						<div class="top col-12">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
  							78
  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
  							15
  						</div>
						<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-1.jpg" alt="Card image cap">
						<div class="card-body">
							<h5 class="card-title col-8">
								Hotel lampa&amp;PATAYA
								<div class="w-100"></div>
								<span>Іспанія</span>
							</h5>
							<div id="price">
								<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
								<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
								<div class="text">від 500 $</div>
							</div>
							<div class="card-text">
								Особи - двоє дорослих
								<div class="w-100"></div>
								від 15.03.2018  -  15.04.2018
							</div>
							<button type="button" class="btn btn-outline-secondary btn-sm">
								забронювати
							</button>
						</div>
					</div>

					<div class="content1">
						<div class="row justify-content-center">
							<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-4.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>
						<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-3.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>
						<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-2.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>
						<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-1.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>


							<div class="w-100"></div>
	  						<button type="button" id="btn2" class="btn btn-outline-secondary">
	  							Показати більше пропозицій
	  							<img src="./wp-content/themes/TravelAgency/img/arrow.png" alt="arrow">
	  						</button>
						</div>
					</div>


					<div class="content2">
						<div class="row justify-content-center">
							<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-2.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>
						<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-3.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>
						<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-4.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>
						<div class="card" style="width: 20rem;">
	  						<div class="top col-12">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/star.png" alt="star">
	  							<img src="./wp-content/themes/TravelAgency/img/man.png" class="offset-5" alt="man">
	  							78
	  							<img src="./wp-content/themes/TravelAgency/img/heart.png" alt="heart">
	  							15
	  						</div>
							<img class="card-img-top" src="./wp-content/themes/TravelAgency/img/pic-2.jpg" alt="Card image cap">
							<div class="card-body">
								<h5 class="card-title col-8">
									Hotel lampa&amp;PATAYA
									<div class="w-100"></div>
									<span>Іспанія</span>
								</h5>
								<div id="price">
									<img src="./wp-content/themes/TravelAgency/img/pic-price.png" class="picPrice" alt="price">
									<img src="./wp-content/themes/TravelAgency/img/fire.png" class="fire" alt="fire">
									<div class="text">від 500 $</div>
								</div>
								<div class="card-text">
									Особи - двоє дорослих
									<div class="w-100"></div>
									від 15.03.2018  -  15.04.2018
								</div>
								<button type="button" class="btn btn-outline-secondary btn-sm">
									забронювати
								</button>
							</div>
						</div>


							<div class="w-100"></div>
	  						<button type="button" id="btn3" class="btn btn-outline-secondary">
	  							<i class="fas fa-angle-double-left"></i>
	  							Показати менше пропозицій
	  						</button>
						</div>
					</div>


					<div class="w-100"></div>
  					<button type="button" id="btn1" class="btn btn-outline-secondary">
  						Показати більше пропозицій
  						<img src="./wp-content/themes/TravelAgency/img/arrow.png" alt="arrow">
  					</button>
  				</div>
  			</div>

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

	<h1><?php the_title(); ?></h1>
	<small><?php the_time('jS F Y') ?></small>
		<?php the_content('Читать далее'); ?>

	<p class="postmetadata">Posted in <?php the_category(', ') ?> by <?php the_author(); ?> <br />
		<?php comments_popup_link('No Comments', '1 Comment', '% Comments');?> </p>
			<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>

<?php endwhile; ?>

	<?php next_posts_link('Older Entries') ?> <?php previous_posts_link('Newer Entries') ?>

	<?php else : ?>
<h1>Не найдено</h1>
<p>Извините, запрашиваемая вами страница не существует</p>
<?php get_search_form(); ?>

<?php endif; ?>

<?php get_footer(); ?>