<?php get_header(); ?>

<h3>Error 404 - Not Found</h3>

<?php get_footer(); ?>