  		<footer>
  			<div class="container-fluid">
  				<div class="row justify-content-center">
  					<div class="menu col-12 col-sm-12 col-md-3">
  						<div class="container">
  							<div class="row justify-content-center">
  								<ul>
	  								<li><a href="">Головна</a></li>
	  								<li><a href="">Автобусом в Європу</a></li>
	  								<li><a href="">Країни</a></li>
	  								<li><a href="">Круїзи</a></li>
	  								<li><a href="">Тури Україною</a></li>
	  								<li><a href="">Раннє бронювання</a></li>
	  								<li><a href="">Акція одного дня</a></li>
	  								<li><a href="">Акція на вікенд</a></li>
  								</ul>
  							</div>
  						</div>
  					</div>
  					<div class="contact col-12 col-sm-12 col-md-3">
  						<div class="container">
  							<div class="row justify-content-left">
  								<i class="fas fa-map-marker-alt float-left"></i>
  								<div class="address float-left">
		  							Адреса:
		  							<div class="w-100"></div>
									м. Львів, вул. Котлярська, 2
		  						</div>
		  						<div class="w-100"></div>
		  						<div class="skype float-left">
		  							<i class="fab fa-skype float-left"></i>
		  							<div class="float-left">
			  							Skype:
			  							<div class="w-100"></div>
			  							flora2115
		  							</div>
		  						</div>
		  						<div class="w-100"></div>
								<i class="fas fa-phone-volume"></i>
		  						<div class="phone float-left">
		  							(032) 297 16-45
		  							<div class="w-100"></div>
		  							(067) 756-58-76
		  						</div>
		  						<div class="w-100"></div>
		  						<div class="director">
		  							<img src="./wp-content/themes/TravelAgency/img/Director.jpg" class="float-left" alt="Director">
		  							<div class="work float-left">Директор:</div>
		  							<div class="w-100"></div>
		  							<div class="name">Прізвище, імя, по-батькові</div>
		  						</div>
  							</div>
  						</div>
  					</div>
  					<div class="social col-12 col-sm-12 col-md-3">
						<div class="row justify-content-center">
							<div class="title">
								Ми в соціальних мережах
							</div>
	  						<div class="w-100"></div>
	  						<span>Знаходьте нас у соціальних мережах та підписуйтесь на цікаві новини</span>
	  						<div class="w-100"></div>
	  						<div class="row justify-content-between">
	  							<a href="#"><img src="./wp-content/themes/TravelAgency/img/icon-Ok.jpg" alt="ok icon"></a>
		  						<a href="#"><img src="./wp-content/themes/TravelAgency/img/icon-G.jpg" alt="g icon"></a>
		  						<a href="#"><img src="./wp-content/themes/TravelAgency/img/icon-F.jpg" alt="f icon"></a>
		  						<a href="#"><img src="./wp-content/themes/TravelAgency/img/icon-Vk.jpg" alt="vk icon"></a>
	  						</div>
						</div>
  					</div>
  					<div class="w-100"></div>
  					<div class="copyright">
  						© 2018 oTITOUR, ТУРОПЕРАТОР
  					</div>
  				</div>
  			</div>
  		</footer>

	    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	    <script src="./wp-content/themes/TravelAgency/main.js" async defer></script>
	    <?php wp_footer(); ?>
  	</body>
</html>
