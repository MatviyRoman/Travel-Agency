<!doctype html>
<html lang="en">
  	<head>
	    <meta charset="utf-8">
	    <meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>">
	    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
	    <link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>">
	    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
		<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
		<?php wp_head(); ?>

	    <title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
  	</head>
  	<body>
  		<header>
  			<div class="container-fluid">
  				<div class="row justify-content-left">
  					<nav class="container-fluid">
  						<div id="logo" class="float-left">
  							<img src="./wp-content/themes/TravelAgency/img/logo.jpg" class="img-fluid" alt="logo">
  						</div>
  						<div class="header-link col-12 offset-md-1">
  							<a href="#" class="float-left">Про нас</a>
  							<a href="#" class="float-left">Оплата</a>
  							<a href="#" class="float-left">Контакти</a>
  							<i class="fas fa-map-marker-alt offset-2 float-left"></i>
  							<div id="address" class="float-left">
  								Адреса:
								<div class="w-100"></div>
								м. Львів, вул. Котлярська, 2
  							</div>
  							<i class="fab fa-skype float-left"></i>
  							<div class="skype float-left">
								Skype:
								<div class="w-100"></div>
								flora2115
  							</div>
  							<i class="fas fa-phone float-left"></i>
							<div class="phone float-none">
								(032) 297 16-45
								<div class="w-100"></div>
								<div class="otherPhone">(067) 756-58-76</div>
							</div>
	  					</div>
						<div class="w-100"></div>
						<div class="menu dropdown float-left">
							<a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Меню
							</a>
							<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
								<a href="#" class="float-left">Головна</a>
	  							<a href="#" class="float-left">Автобусом в Європу</a>
	  							<a href="#" class="float-left">Країни</a>
			  					<a href="#" class="float-left">Круїзи</a>
			  					<a href="#" class="float-left">Тури Україною</a>
			  					<a href="#" class="float-left">Раннє бронювання</a>
			  					<a href="#" class="float-left">Акція одного дня</a>
			  					<a href="#" class="float-left">Акція на вікенд</a>
							</div>
  						</div>
						<div class="footer-link offset-0 offset-md-1">
							<a href="#" class="float-left">Головна</a>
		  					<a href="#" class="float-left">Автобусом в Європу</a>
		  					<div class="dropdown float-left">
								<a href="#" class="country" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								    Країни
								    <i class="iconShow fas fa-angle-down"></i>
								    <i class="iconHide fas fa-angle-up"></i>
								</a>
							  	<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
							    	<a class="dropdown-item" href="#">Турція</a>
							    	<a class="dropdown-item" href="#">Чехія</a>
							    	<a class="dropdown-item" href="#">Італія</a>
							    	<a class="dropdown-item" href="#">Єгипет</a>
							  	</div>
							</div>
		  					<a href="#" class="float-left">Круїзи</a>
		  					<a href="#" class="float-left">Тури Україною</a>
		  					<a href="#" class="float-left">Раннє бронювання</a>
		  					<a href="#" class="float-left">Акція одного дня</a>
		  					<a href="#" class="float-left">Акція на вікенд</a>
						</div>
	  				</nav>
	  			</div>
	  		</div>
	  	</header>
		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active circle"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="1" class="circle"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="2" class="circle"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="3" class="circle"></li>
			</ol>
			<div class="carousel-inner">
				<div class="carousel-item active">
					<img class="d-block w-100" src="./wp-content/themes/TravelAgency/img/img.jpg" alt="pic-1">
		  			<div class="carousel-caption d-block d-md-block">
		    			<h1>Нові горизонти Вашого відпочинку</h1>
		    			<p>Ми поставили перед собою завдання зробити якісний відпочинок доступним для всіх українських сімей і розробили нову концепцію щасливого і безтурботного відпочинку з дітьми</p>
		  			</div>
				</div>
				<div class="carousel-item">
			  		<img class="d-block w-100" src="./wp-content/themes/TravelAgency/img/img1.jpg" alt="pic-2">
		  			<div class="carousel-caption d-block d-md-block">
		    			<h1 class="fluid">Нові горизонти Вашого відпочинку</h1>
		    			<p>Ми поставили перед собою завдання зробити якісний відпочинок доступним для всіх українських сімей і розробили нову концепцію щасливого і безтурботного відпочинку з дітьми</p>
		  			</div>
				</div>
				<div class="carousel-item">
					<img class="d-block w-100" src="./wp-content/themes/TravelAgency/img/img.jpg" alt="pic-3">
			  		<div class="carousel-caption d-block d-md-block">
			    		<h1 class="fluid">Нові горизонти Вашого відпочинку</h1>
			    		<p>Ми поставили перед собою завдання зробити якісний відпочинок доступним для всіх українських сімей і розробили нову концепцію щасливого і безтурботного відпочинку з дітьми</p>
			  		</div>
			  	</div>
			  	<div class="carousel-item">
				  	<img class="d-block w-100" src="./wp-content/themes/TravelAgency/img/img1.jpg" alt="pic-2">
			  		<div class="carousel-caption d-block d-md-block">
			    		<h1 class="fluid">Нові горизонти Вашого відпочинку</h1>
			    		<p>Ми поставили перед собою завдання зробити якісний відпочинок доступним для всіх українських сімей і розробили нову концепцію щасливого і безтурботного відпочинку з дітьми</p>
			  		</div>
				</div>
			</div>
			<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			<span aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			<span aria-hidden="true"></span>
			<span class="sr-only">Next</span>
			</a>
		</div>
  		<?php get_sidebar(); ?>
  		<div class="content">